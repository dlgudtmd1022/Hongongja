package sec01.exam01;

public interface RemoteControl {// 인터페이스 선언
	

}
