package sec02.exam02;

public class Child extends Parent {

	@Override//재정의
	public void method2() {
		// TODO Auto-generated method stub
		System.out.println("Child-method2()");
	}
	
	public void method3() {
		System.out.println("Child-method3()");
	}
	
}
