package sec02.exam02;

public interface Vehicle {//인터페이스
	public void run();

}
