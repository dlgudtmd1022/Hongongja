package sec04.exam04;

public class CalculatorExam {

	public static void main(String[] args) {//Calculator의 execute()실행
		Calculator myCalc=new Calculator();
		myCalc.execute();//Calculator의 execute()메소드 호출

	}

}
