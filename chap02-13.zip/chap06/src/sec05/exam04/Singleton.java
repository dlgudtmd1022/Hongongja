package sec05.exam04;

public class Singleton {
	// 싱글톤 : 전체프로그램에서 단 하나의 객체만 생성되는 것
	// 싱글톤을 만들려면 클래스 외부에서 new 연산자로 생성자를 호출할 수 없도록
	// 막아야한다. 생성자를 호출한 만큼 객체가 생성되기 때문.
	// 따라서 생성자 앞에 private접근 제한자를 붙여주면 된다.
	
	//정적 필드
	private static Singleton singleton=new Singleton();
	
	//생성자
	private Singleton() {}
		
		//정적 메소드
	public static Singleton getInstance() {//외부에서 객체를 얻는 유일한 방법
		return singleton;
		//getInstance() 메소드는 단 하나의 객체만 리턴함
	}
}
