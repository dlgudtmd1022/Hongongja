package sec02.exam10;

public class AssignmentOperatorExam {

	public static void main(String[] args) {
		int result=0;
		result+=10;
		System.out.println(result);
		result-=5;
		System.out.println(result);
		result*=3;
		System.out.println(result);
		result/=5;
		System.out.println(result);
		result%=3;
		System.out.println(result);

	}

}
