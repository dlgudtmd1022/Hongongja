package verify.exam03;

public class MemberServiceExam {
	public static void main(String[] args) {
		MemberService memberService = new MemberService();
		boolean result = memberService.login("hong","12345");
		if(result) {
			System.out.println("로그인");
			memberService.logout("hong");
		}else {
			System.out.println("id 또는 password 오류");
		}
	}
}
