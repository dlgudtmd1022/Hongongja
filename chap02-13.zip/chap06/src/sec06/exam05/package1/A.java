package sec06.exam05.package1;

public class A {//필드와 메소드의 접근제한1
	//필드
	public int field1; //public접근제한
	int field2;	//default접근제한
	private int field3;//private접근제한
	
	//생성자
	public A() {//클래스 내부일 경우 접근 제한자의 영향을 받지 않음
		field1=1;
		field2=1;
		field3=1;
		
		method1();
		method2();
		method3();
	}
	
	//메소드
	public void method1() {}
	void method2() {}
	private void method3() {}
}
