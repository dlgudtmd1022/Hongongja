package sec02.exam05;
//하위 인터페이스
public interface InterfaceC extends InterfaceA, InterfaceB {
	public void methodC();
}
