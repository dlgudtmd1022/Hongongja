package sec01.exam05;

public final class Member {//상속할 수 없느 final클래스

}
