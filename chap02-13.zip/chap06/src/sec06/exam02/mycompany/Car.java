package sec06.exam02.mycompany;

import sec06.exam02.hankook.SnowTire;
import sec06.exam02.hyundai.Engine;
import sec06.exam02.kumho.BigWidthTire;

public class Car {
	//import문 : 사용하고자 하는 클래스 또는 인터페이스가 다른 패키지에
	//소속되어 있다면, import문으로 해당 패키지의 클래스 또는 인터페이스를 가져와 사용할 것임을
	//알려줘야 한다.
	
	//import 상위패키지.하위패키지.클래스명;
	//import 상위패키지.하위패키지.*;
	
	//필드
	Engine engine = new Engine();
	SnowTire tire1=new SnowTire();
	BigWidthTire tire2=new BigWidthTire();
	sec06.exam02.hankook.Tire tire3=new sec06.exam02.hankook.Tire();
	sec06.exam02.kumho.Tire tire4=new sec06.exam02.kumho.Tire();
	
	
	//Tire 클래스는 import된 두 패키지(hankook, kumho)에 모두 있기 때문에 19-20라인처럼
	//패키지 이름과 함께 전체 이름이 기술되어야 한다. 16라인의 엔진클래스는 현대 패키지에만 존재하기
	//때문에 아무런 문제가 없고, 17-18라인의 스노우타이어와 빅위드스타이어 클래스도 각각 한국,금호
	//패키지에만 존재하기 때문에 아무런 문제가 없다.
	
}
