package sec02.exam08;

public class BooleanExam {

	public static void main(String[] args) {
		boolean stop = true; // if블록 실행시 "중지합니다"출력
		//boolean state = false;// else블록 실행시 "시작합니다"출력
		if(stop) {
			System.out.println("중지합니다.");
		}else {
			System.out.println("시작합니다.");
		}
		
		
		
		

	}

}
