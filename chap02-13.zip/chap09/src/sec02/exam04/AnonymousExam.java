package sec02.exam04;
//익명 객체의 로컬 변수 사용
public class AnonymousExam {

	public static void main(String[] args) {
		Anonymous anony = new Anonymous();
		anony.method(0, 0);

	}

}
