package sec01.exam07.pack1;

public class B {//protected 접근 제한자 테스트
	public void method() {
		A a=new A();
		a.field ="value";
		a.method();
	}// 접근 가능
	

}
