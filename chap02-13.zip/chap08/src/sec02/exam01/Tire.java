package sec02.exam01;

public interface Tire {//인터페이스
	public void roll();//roll()메소드 호출 방법 설명
	
}
