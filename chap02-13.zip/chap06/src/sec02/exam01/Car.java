package sec02.exam01;

public class Car {
	//Car클래스 필드 선언
	String company="현대자동차";
	String model="그랜져";
	String color="검정";
	int maxSpeed=350;
	int speed;
}
