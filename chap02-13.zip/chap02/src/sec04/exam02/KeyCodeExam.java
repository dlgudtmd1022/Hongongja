package sec04.exam02;

public class KeyCodeExam {

	public static void main(String[] args) throws Exception{
		int keyCode;
		
		keyCode = System.in.read();
		System.out.println("keyCode: "+keyCode);
		
		keyCode = System.in.read();
		System.out.println("keyCode: "+keyCode);
		
		keyCode = System.in.read();
		System.out.println("keyCode: "+keyCode);
		
		

	}

}
