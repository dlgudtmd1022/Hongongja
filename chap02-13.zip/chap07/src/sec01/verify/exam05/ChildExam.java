package sec01.verify.exam05;

public class ChildExam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child child = new Child();
	}

}
