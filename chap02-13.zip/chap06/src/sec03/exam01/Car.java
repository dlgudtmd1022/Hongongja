package sec03.exam01;

public class Car {
	//생성자
	Car(String color, int cc){
		
	}
}
