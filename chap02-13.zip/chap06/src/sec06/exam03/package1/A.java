package sec06.exam03.package1;
//클래스의 접근제한1
class A {//default 접근 제한
	

}
