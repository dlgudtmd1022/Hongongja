package sec02.exam04;
//인터페이스
public interface Calculatable {
	public int sum();
}
