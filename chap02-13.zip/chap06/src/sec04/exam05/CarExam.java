package sec04.exam05;

public class CarExam {
	public static void main(String[] args) {//클래스 외부에서 메소드 호출
		Car myCar = new Car();
		myCar.keyTunrOn();
		myCar.run();
		int speed=myCar.getSpeed();
		System.out.println("현재속도"+speed);
	}
	//외부 클래스에서 메소드를 호출하려면 클래스로부터 객체를 생성해야한다.
	//메소드는 객체에 소속된 멤버이므로 객체가 존재하지 않으면 메소드도 존재하지 않기 때문
}
