package sec03.exam04;

public class Car {// 다른생성자를 호출해서 중복 코드 줄이기
	//필드
	String company="현대자동차";
	String model;
	String color;
	int maxSpeed;
	
	//생성자
	Car(){}
	
	Car(String model){//호출
		this(model,"은색",250);
	}
	
	Car(String model, String color){//호출
		this(model, color, 250);
	}
	
	Car(String model, String color, int maxSpeed){
		//공통 실행 코드
		this.model=model;
		this.color=color;
		this.maxSpeed=maxSpeed;
	}
	
	// Car(String model, String color, int maxSpeed)를 호출하도록
	// 수정하면 중복코드를 최소화 할 수 있다.
}
