package sec02.exam01;
//익명 자식객체 생성-부모클래스 제작
public class Person {
	void wake() {
		System.out.println("7시에 일어납니다.");
	}
}
