package sec05.exam06;

public class EarthExam {

	public static void main(String[] args) {
		// 상수 사용
		System.out.println("지구의 반지름: "+Earth.EARTH_RADIUS+"km");
		System.out.println("지구의 표면적: "+Earth.EARTH_AREA+"km^2");
		

	}

}
