package sec05.exam02;

public class Calculator {//정적 멤버 사용
	//정적 멤버: 클래스에 고정된 멤버로서 객체를 생성하지 않고
	//사용할 수 있는 필드와 메소드를 말한다.
	
	//정적 필드
	//static 타입 필드[=초기값];
	
	//정적 메소드
	//static 리턴타입 메소드(매개변수선언, ...){...}
	
	static double pi=3.14159;
	
	static int plus(int x,int y) {
		return x+y;
	}
	
	static  int minus(int x, int y) {
		return x-y;
	}

}
