package verify.exam03;

public class Exam03_04 {
	/*
	Board board=new Board("제목","내용");
	Board board=new Board("제목","내용","홍길동");
	Board board=new Board("제목","내용","홍길동","2025-12-31");
	Board board=new Board("제목","내용","홍길동","2025-12-31",0);
	*/
}
