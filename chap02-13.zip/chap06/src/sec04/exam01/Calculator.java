package sec04.exam01;

public class Calculator {//메소드 선언(메소드 시그니쳐)
	//리턴 타입:메소드가 리턴하는 결과의 타입을 표시한다.
	//메소드명:메소드의 기능이 드러나도록 식별자 규칙에 맞게 이름을 지어준다.
	//매개 변수 선언:메소드를 실행할 때 필요한 데이터를 받기 위한 변수를 선언
	//메소드 실행 블록: 실행할 코드를 작성
	
	//메소드
	void powerOn() {
		System.out.println("turn on");
	}
	
	int plus(int x, int y) {
		int result=x+y;
		return result;
	}
	
	double divide(int x, int y) {
		double result=(double)x/(double)y;
		return result;
	}
	
	void powerOff() {
		System.out.println("turn off");
	}
	
	// 외부 클래스에서 Calculator 클래스의 메소드를 호출하기 위해서는
	// 5라인에서 Calculator객체를 생성하고 참조 변수인 myCalc를 이용
	//해야한다. myCalc 변수에 도트(.)와 함께'메소드이름(매개값)'형태로 호출하면
	//메소드블록이 실행된다.

}
