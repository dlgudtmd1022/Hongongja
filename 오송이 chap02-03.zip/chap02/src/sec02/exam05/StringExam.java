package sec02.exam05;

public class StringExam {

	public static void main(String[] args) {
		String name="홍길동";
		String job="프로그래머";
		System.out.println(name);
		System.out.println(job);

		String str = "나는 \"자바\"를 좋아합니다.";
		System.out.println(str);
		
		String str2 = "번호\t이름\t나이";
		System.out.println(str2);
		
		String str3="홍길동\n김자바";
		System.out.println(str3);
	}

}
