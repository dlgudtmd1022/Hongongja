package sec01.exam05;

public class VeryImportantPerson {//상속할 수 없는 final 클래스
	
//	public class VeryImportantPerson extends Member{}
	//멤버 상속 불가

}
