package sec01.exam02;
//게시물 정보 객체
public class Board {
	String subject;
	String content;
	String writer;
	
	public Board(String subject, String conctent, String writer) {
		this.subject=subject;
		this.content=conctent;
		this.writer=writer;
				
	}
}
