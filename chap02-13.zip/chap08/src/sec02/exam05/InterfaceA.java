package sec02.exam05;

public interface InterfaceA {//상위 인터페이스
	public void methodA();
}
