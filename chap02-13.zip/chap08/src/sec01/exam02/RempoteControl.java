package sec01.exam02;

public interface RempoteControl {
	public int MAX_VOLUME=10;
	public int MIN_VOLUME=0;
}
