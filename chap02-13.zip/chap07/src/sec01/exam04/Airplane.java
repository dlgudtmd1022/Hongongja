package sec01.exam04;

public class Airplane {
	public void land() {
		System.out.println("착륙");
	}
	public void fly() {
		System.out.println("일반비행");
	}
	public void takeOff() {
		System.out.println("이륙");
	}
}
