package sec02.exam05;

public interface InterfaceB {//상위 인터페이스
	public void methodB();
}
