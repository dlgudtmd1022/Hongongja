package sec02.exam02;

public class FieldInitValExam {//필드값 출력

	public static void main(String[] args) {
		FieldInitVal fiv=new FieldInitVal();
		
		System.out.println(fiv.byteField);
		System.out.println(fiv.shortField);
		System.out.println(fiv.intField);
		System.out.println(fiv.longField);
		System.out.println(fiv.booleanField);
		System.out.println(fiv.charField);
		System.out.println(fiv.floatField);
		System.out.println(fiv.doubleField);
		System.out.println(fiv.arrField);
		System.out.println(fiv.referenceField);
		
		

	}

}
