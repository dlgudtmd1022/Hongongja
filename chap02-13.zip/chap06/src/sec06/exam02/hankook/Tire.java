package sec06.exam02.hankook;

public class Tire {

}
