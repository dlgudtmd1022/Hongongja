package sec06.exam02.kumho;

public class BigWidthTire {

}
