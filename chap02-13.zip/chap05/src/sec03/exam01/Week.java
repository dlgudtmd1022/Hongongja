package sec03.exam01;

public enum Week {
	//열거 타입 선언
	//열거 타입을 선언하기 위해서는 먼저 열거 타입의 이름을 정하고 해당 이름으로 
	//소스파일(.java)을 생성해야 한다.
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY
}
