package sec06.exam05.package1;

public class B {//필드와 메소드의 접근제한2
	public B() {
		A a =new A();
		a.field1 = 1;
		a.field2 = 1;
		//a.field3=1; private 필드 접근불가
		
		a.method1();
		a.method2();
		//a.method3();
	}

}
