package sec05.exam01;

public class CarExam {//인스턴스 멤버와 this

	public static void main(String[] args) {
		//인스턴스멤버:객체(인스턴스)를 생성한 후 사용할 수 있는 필드와 메소드
		Car myCar=new Car("포르쉐");
		Car yourCar=new Car("벤츠");
		
		myCar.run();
		yourCar.run();
		

	}

}
