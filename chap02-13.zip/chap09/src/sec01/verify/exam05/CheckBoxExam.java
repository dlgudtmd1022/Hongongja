package sec01.verify.exam05;

public class CheckBoxExam {

	public static void main(String[] args) {
		CheckBox checkBox = new CheckBox();
		
		//checkBox.setOnSelectListener(new BackgroundChangeListener());
		checkBox.select();

	}

}
