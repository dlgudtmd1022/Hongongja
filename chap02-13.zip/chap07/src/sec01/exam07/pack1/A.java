package sec01.exam07.pack1;

public class A {// protected 접근 제한자
	protected String field;
	
	protected A() {
		
	}
	
	protected void method() {
		
	}
	
}
