package sec01.exam02;

public class People {// 부모 클래스
	public String name;
	public String ssn;
	
	public People(String name, String ssn) {
		this.name=name;
		this.ssn=ssn;
	}
}
