package sec02.exam04;

public class Vehicle {
	public void run() {
		System.out.println("Car Run");
	}
}
