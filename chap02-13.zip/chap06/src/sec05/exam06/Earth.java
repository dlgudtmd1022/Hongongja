package sec05.exam06;

public class Earth {
	//상수 :불변의 값을 저장하는 필드(객체마다 저장할 필요가 없는 공용성을 띄고 있다.)
	//생성자의 매개값을 통해서 여러 가지 값을 가질 수 있다.(!=상수)
	
	//상수 선언
	static final double EARTH_RADIUS=6400;
	static final double EARTH_AREA=4*Math.PI*EARTH_RADIUS*EARTH_RADIUS;
	
}
