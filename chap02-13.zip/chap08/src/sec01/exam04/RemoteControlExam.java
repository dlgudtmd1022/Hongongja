package sec01.exam04;

import sec01.exam03.RemoteControl;

public class RemoteControlExam {
	public static void main(String[] args) {
		RemoteControl rc;
		rc=new Television();
		rc=new Audio();
	}
}
