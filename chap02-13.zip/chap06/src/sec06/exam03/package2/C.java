package sec06.exam03.package2;

import sec06.exam03.package1.B;//클래스의 접근제한3

public class C {
	//A a; ->A클래스 접근불가(컴파일 에러)
	B b;
	
	//C클래스는 A클래스와 다른패키지 이므로 default 접근 제한을 갖는 A클래스에는 접근이
	//되지 않지만, public 접근 제한을 갖는 B클래스는 접근이 가능하다.
	//그래서 C클래스에서 B클래스를 이용하여 필드 선언 및 생성자/메소드 내부에서 변수선언이 가능
	
}
