package sec05.exam03;

public class Car {
	// 정적 메소드 선언시 주의점:객체가 없어도 실행된다는 특징때문에 정적 메소드를 선언시 이들 내부에
	// 인스턴스 필드나 인스턴스 메소드를 사용할 수 없다. 또한 객체 자신의 참조인 this 키워드도 사용불가
	// 정적 메소드에서 인스턴스 멤버를 사용하고 싶다면 객체를 먼저 생성하고 참조변수로 접근해야 한다.
	
	int speed;
	
	void run() {
		System.out.println(speed+"으로 달립니다.");
	}
	
	public static void main(String[] args) {
		Car myCar=new Car();
		myCar.speed=60;
		myCar.run();
	}
	
}
