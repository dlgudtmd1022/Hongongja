package sec03.exam01;

public class CarExam {

	public static void main(String[] args) {
		// 생성자를 호출해서 객체 생성
		Car myCar=new Car("검정", 3000);
		//Car myCar=new Car(); 기본생성자를 호출할 수 없음
		//매개변수를 선언하지 않았기 때문

	}

}
